package com.todo.project.todoProject.test.service;

import java.util.Map;

public interface TestService {
    public Map<String,Object> firstData();
}
