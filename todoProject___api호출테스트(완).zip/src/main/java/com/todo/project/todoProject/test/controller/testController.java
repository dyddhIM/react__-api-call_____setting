package com.todo.project.todoProject.test.controller;

import com.todo.project.todoProject.test.service.TestService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequiredArgsConstructor
public class testController {

private  final TestService service;

    @GetMapping("/first")
    public Map<String, Object> testControler (){

    return  service.firstData();
    }

}
