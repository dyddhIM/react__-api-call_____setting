package com.todo.project.todoProject.test.service.serviceImpl;

import com.todo.project.todoProject.test.service.TestService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class TestServiceImpl implements TestService {
    @Override
    public Map<String, Object> firstData() {
        Map<String, Object> first = new HashMap();
        first.put("id","나는 id");
        first.put("pw", "나는 pw");
        return first;
    }
}
